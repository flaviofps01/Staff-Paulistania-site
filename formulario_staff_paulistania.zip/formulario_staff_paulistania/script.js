
const WEBHOOK_URL = "https://discord.com/api/webhooks/1449162575584432193/6Ulv1MBBmr0cGUBqWGLqwU39mXmMvbwsW1wEqWz2qtRhRhzMGwklgLo0Qi1Lf-2LDyXm";

document.getElementById("staffForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const fields = document.querySelectorAll("input, textarea");
    let msg = "**📋 NOVA INSCRIÇÃO STAFF – PAULISTÂNIA RP**\n\n";

    fields.forEach(field => {
        const label = field.previousElementSibling.innerText;
        msg += `**${label}** ${field.value}\n`;
    });

    fetch(WEBHOOK_URL, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({content: msg})
    }).then(() => {
        alert("Formulário enviado com sucesso!");
        document.getElementById("staffForm").reset();
    }).catch(() => {
        alert("Erro ao enviar formulário.");
    });
});
